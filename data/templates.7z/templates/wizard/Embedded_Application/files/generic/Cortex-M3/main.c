/************************************************************************************
 *  File:     main.c
 *  Purpose:  Cortex-M3 main file.
 *            Replace with your code.
 *  Date:     05 July 2013
 *  Info:     If __NO_SYSTEM_INIT is defined in the Build options, 
 *            the startup code will not branch to SystemInit()
 *            and the function can be removed
 ************************************************************************************/


#ifndef __NO_SYSTEM_INIT
void SystemInit()
{}
#endif

/*********************************************************************
 *  
 *  main()
 *  
 *********************************************************************/
void main()
{
  /******************************************************************
   *
   *  Place your code here.                                          
   ******************************************************************/
  int cnt;
  cnt = 0;
  do {
    cnt++;
  } while (1);
}
